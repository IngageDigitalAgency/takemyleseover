if ($('#messages div .alert').length > 0) showMessages();
